    if ~exist('q')
        q = ds.segs(si).q(ds.segs(si).tchosenindx);
    end

    labels = ds.segs(si).tchosen;
    badspikes = [];
    badinds = [];
    spikes = section(ds.dataset,ds.segs(si).start,ds.segs(si).finish);
    goodspikes = spikes(:,:,1);
    goodlabels = labels;
    goodinds = 1:size(spikes,1);
    for i=1:length(unique(labels))
        if ds.segs(si).tsig(i) > ds.segs(si).sigsplit
            badspikes = [badspikes; spikes(labels==i,:,1)];
            badinds = [badinds goodinds(labels==i)];
            goodspikes(labels==i,:) = 0;
            goodlabels(labels==i) = 0;
            goodinds(labels==i) = 0;
        end
    end

    jj = find(goodlabels==0);
    goodlabels(jj) = [];
    goodlabels = relabel(goodlabels);
    goodlabels = goodlabels(:)';
    goodspikes(jj,:)=[];
    goodinds(jj) = [];
    goodinds = goodinds(:)';
    tlabels = [repmat(0,[1 size(badspikes,1)]) goodlabels];
    tspikes = [badspikes; goodspikes];

    ms = squeeze(vpmetric(tspikes,q,0))
    ms = ms(1:size(badspikes,1),(size(badspikes,1)+1):end);
    tms = [];
    for i=1:length(unique(goodlabels))
        tms = [tms mean(ms(:,goodlabels==i),2)];
    end

    mns = min(tms,[],2);
    badinds = badinds(:)';
    bestspikes = [];
    bestlabels = [];
    bestinds = [];
    for i=1:length(unique(goodlabels))
        inds = find(mns==i);
        temp = [goodspikes(goodlabels==i,:); badspikes(inds,:)];
        bestlabels = [bestlabels repmat(i,[1 size(temp,1)]) ];
        bestspikes = [bestspikes; temp];
        bestinds = [bestinds goodinds(goodlabels==i) badinds(inds)];
    end
    

