% This is a script to generate a fake data set


