addpath('/afs/physics/project/tiesinga/students/toups/textmodutils/')
