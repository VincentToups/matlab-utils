!screen vim ~/www/rplog.md "+:recover"


